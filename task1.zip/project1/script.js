// =======================================================
// Student Grade Tracker - script.js
// Beginner-friendly, well-commented JavaScript.
// =======================================================

// This array is our "database" - it stores all student records
// in memory. Each record looks like: { name, id, grade }
let students = [];

// -------------------------------------------------------
// Grab references to all the DOM elements we need
// -------------------------------------------------------
const form = document.getElementById("student-form");
const nameInput = document.getElementById("student-name");
const idInput = document.getElementById("student-id");
const gradeInput = document.getElementById("student-grade");

const nameError = document.getElementById("name-error");
const idError = document.getElementById("id-error");
const gradeError = document.getElementById("grade-error");

const clearBtn = document.getElementById("clear-btn");

const tableBody = document.getElementById("student-table-body");
const emptyMessage = document.getElementById("empty-message");

const totalStudentsEl = document.getElementById("total-students");
const averageScoreEl = document.getElementById("average-score");
const highestScoreEl = document.getElementById("highest-score");
const lowestScoreEl = document.getElementById("lowest-score");

// -------------------------------------------------------
// Handle form submission (Add Student button)
// -------------------------------------------------------
form.addEventListener("submit", function (event) {
  // Stop the browser from reloading the page on submit
  event.preventDefault();

  // Read and clean up the current input values
  const name = nameInput.value.trim();
  const id = idInput.value.trim();
  const gradeRaw = gradeInput.value.trim();

  // Run validation. If it fails, stop here.
  const isValid = validateInputs(name, id, gradeRaw);
  if (!isValid) {
    return;
  }

  // Convert the grade to a number now that we know it's valid
  const grade = Number(gradeRaw);

  // Add the new student to our array
  students.push({ name: name, id: id, grade: grade });

  // Refresh the table and summary stats to show the new student
  renderTable();
  updateSummary();

  // Clear the form so it's ready for the next entry
  clearForm();
});

// -------------------------------------------------------
// Handle "Clear Form" button
// -------------------------------------------------------
clearBtn.addEventListener("click", function () {
  clearForm();
});

// -------------------------------------------------------
// Validation function
// Checks all fields are filled in and grade is 0-100.
// Displays error messages next to each invalid field.
// Returns true if everything is valid, false otherwise.
// -------------------------------------------------------
function validateInputs(name, id, gradeRaw) {
  let isValid = true;

  // Reset previous error states before re-checking
  clearErrors();

  // --- Name check ---
  if (name === "") {
    showError(nameInput, nameError, "Student name is required.");
    isValid = false;
  }

  // --- ID check ---
  if (id === "") {
    showError(idInput, idError, "Student ID is required.");
    isValid = false;
  }

  // --- Grade check ---
  if (gradeRaw === "") {
    showError(gradeInput, gradeError, "Grade is required.");
    isValid = false;
  } else {
    const gradeNum = Number(gradeRaw);
    if (isNaN(gradeNum)) {
      showError(gradeInput, gradeError, "Grade must be a valid number.");
      isValid = false;
    } else if (gradeNum < 0 || gradeNum > 100) {
      showError(gradeInput, gradeError, "Grade must be between 0 and 100.");
      isValid = false;
    }
  }

  return isValid;
}

// Show an error message and highlight the offending input
function showError(inputEl, errorEl, message) {
  errorEl.textContent = message;
  inputEl.classList.add("invalid");
}

// Clear all error messages and input highlighting
function clearErrors() {
  nameError.textContent = "";
  idError.textContent = "";
  gradeError.textContent = "";

  nameInput.classList.remove("invalid");
  idInput.classList.remove("invalid");
  gradeInput.classList.remove("invalid");
}

// Reset the form fields and any error messages
function clearForm() {
  form.reset();
  clearErrors();
  nameInput.focus();
}

// -------------------------------------------------------
// Render the student table based on the `students` array
// -------------------------------------------------------
function renderTable() {
  // Clear out any existing rows first
  tableBody.innerHTML = "";

  // Show/hide the "no students yet" message
  if (students.length === 0) {
    emptyMessage.style.display = "block";
  } else {
    emptyMessage.style.display = "none";
  }

  // Figure out the current highest and lowest scores so we can
  // visually highlight them in the table
  const scores = students.map(function (s) { return s.grade; });
  const highest = scores.length ? Math.max(...scores) : null;
  const lowest = scores.length ? Math.min(...scores) : null;

  // Build one table row per student
  students.forEach(function (student, index) {
    const row = document.createElement("tr");

    // Highlight the top scorer(s) and bottom scorer(s)
    if (student.grade === highest && highest !== lowest) {
      row.classList.add("highlight-high");
    } else if (student.grade === lowest && highest !== lowest) {
      row.classList.add("highlight-low");
    }

    row.innerHTML =
      "<td>" + escapeHtml(student.name) + "</td>" +
      "<td>" + escapeHtml(student.id) + "</td>" +
      "<td>" + student.grade + "</td>" +
      "<td><button class='btn-danger' data-index='" + index + "'>Remove</button></td>";

    tableBody.appendChild(row);
  });

  // Wire up the "Remove" buttons for each row
  const removeButtons = tableBody.querySelectorAll(".btn-danger");
  removeButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      const indexToRemove = Number(btn.getAttribute("data-index"));
      students.splice(indexToRemove, 1);
      renderTable();
      updateSummary();
    });
  });
}

// -------------------------------------------------------
// Update the Summary Report section
// -------------------------------------------------------
function updateSummary() {
  const total = students.length;

  totalStudentsEl.textContent = total;

  if (total === 0) {
    // No data yet, so show placeholders instead of numbers
    averageScoreEl.textContent = "-";
    highestScoreEl.textContent = "-";
    lowestScoreEl.textContent = "-";
    return;
  }

  const scores = students.map(function (s) { return s.grade; });

  const sum = scores.reduce(function (acc, score) { return acc + score; }, 0);
  const average = sum / total;
  const highest = Math.max(...scores);
  const lowest = Math.min(...scores);

  averageScoreEl.textContent = average.toFixed(1);
  highestScoreEl.textContent = highest;
  lowestScoreEl.textContent = lowest;
}

// -------------------------------------------------------
// Small helper to prevent HTML injection when displaying
// student-entered text (name/ID) in the table.
// -------------------------------------------------------
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// -------------------------------------------------------
// Initial render on page load (table starts empty)
// -------------------------------------------------------
renderTable();
updateSummary();