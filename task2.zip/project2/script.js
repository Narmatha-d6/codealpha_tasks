// =======================================================
// Stock Trading Platform - script.js
// Built with Object-Oriented Programming (OOP) principles.
// Classes: Stock, Transaction, Portfolio, User
// =======================================================

// -------------------------------------------------------
// CLASS: Stock
// Represents a single tradable stock on the market.
// -------------------------------------------------------
class Stock {
  constructor(symbol, name, basePrice) {
    this.symbol = symbol;
    this.name = name;
    this.basePrice = basePrice;   // yesterday's / reference price
    this.price = basePrice;       // current simulated price
  }

  // Simulate a small random price movement (-3% to +3%)
  // Called once when the page loads, to mimic a "live" market.
  simulatePriceChange() {
    const percentChange = (Math.random() * 6 - 3) / 100; // -0.03 to +0.03
    const newPrice = this.basePrice * (1 + percentChange);
    this.price = Math.max(1, Number(newPrice.toFixed(2))); // never below $1
  }

  // Percentage change vs the reference/base price
  getChangePercent() {
    return ((this.price - this.basePrice) / this.basePrice) * 100;
  }
}

// -------------------------------------------------------
// CLASS: Transaction
// Represents a single buy or sell event in the history log.
// -------------------------------------------------------
class Transaction {
  constructor(symbol, type, quantity, price) {
    this.date = new Date().toLocaleString();
    this.symbol = symbol;
    this.type = type;             // "BUY" or "SELL"
    this.quantity = quantity;
    this.price = price;
    this.total = quantity * price;
  }
}

// -------------------------------------------------------
// CLASS: Portfolio
// Tracks what the user owns: holdings keyed by stock symbol.
// Each holding stores: shares owned + average purchase price.
// -------------------------------------------------------
class Portfolio {
  constructor(holdings) {
    // holdings: { AAPL: { shares: 10, avgPrice: 150 }, ... }
    this.holdings = holdings || {};
  }

  // Add shares to a holding, updating the average purchase price
  addShares(symbol, quantity, price) {
    const existing = this.holdings[symbol];

    if (existing) {
      const totalCost = existing.shares * existing.avgPrice + quantity * price;
      const totalShares = existing.shares + quantity;
      existing.shares = totalShares;
      existing.avgPrice = totalCost / totalShares;
    } else {
      this.holdings[symbol] = { shares: quantity, avgPrice: price };
    }
  }

  // Remove shares from a holding (average price stays the same)
  removeShares(symbol, quantity) {
    const existing = this.holdings[symbol];
    if (!existing) return;

    existing.shares -= quantity;

    // If all shares are sold, remove the holding entirely
    if (existing.shares <= 0) {
      delete this.holdings[symbol];
    }
  }

  // How many shares of a given symbol does the user own?
  getSharesOwned(symbol) {
    return this.holdings[symbol] ? this.holdings[symbol].shares : 0;
  }

  // Number of distinct stocks owned
  getStockCount() {
    return Object.keys(this.holdings).length;
  }
}

// -------------------------------------------------------
// CLASS: User
// Ties together cash balance, portfolio, and transaction history.
// -------------------------------------------------------
class User {
  constructor(cash, holdings, transactions) {
    this.cash = cash;
    this.portfolio = new Portfolio(holdings);
    this.transactions = (transactions || []).map(function (t) {
      // Rebuild plain objects loaded from localStorage into Transaction-shaped data
      return t;
    });
  }

  // Buy shares of a stock, if the user has enough cash
  buyStock(stock, quantity) {
    const cost = stock.price * quantity;

    if (cost > this.cash) {
      return { success: false, message: "Not enough cash to complete this purchase." };
    }

    this.cash -= cost;
    this.portfolio.addShares(stock.symbol, quantity, stock.price);

    const transaction = new Transaction(stock.symbol, "BUY", quantity, stock.price);
    this.transactions.unshift(transaction); // newest first

    return { success: true };
  }

  // Sell shares of a stock, if the user owns enough
  sellStock(stock, quantity) {
    const owned = this.portfolio.getSharesOwned(stock.symbol);

    if (quantity > owned) {
      return { success: false, message: "You cannot sell more shares than you own." };
    }

    const proceeds = stock.price * quantity;
    this.cash += proceeds;
    this.portfolio.removeShares(stock.symbol, quantity);

    const transaction = new Transaction(stock.symbol, "SELL", quantity, stock.price);
    this.transactions.unshift(transaction);

    return { success: true };
  }
}

// =======================================================
// APPLICATION SETUP
// =======================================================

// Local Storage keys
const STORAGE_KEY_CASH = "trading_app_cash";
const STORAGE_KEY_HOLDINGS = "trading_app_holdings";
const STORAGE_KEY_TRANSACTIONS = "trading_app_transactions";

// Starting cash for a brand-new user (only used the very first time)
const STARTING_CASH = 10000;

// Preloaded market data: symbol, company name, base price
const stocks = [
  new Stock("AAPL", "Apple Inc.", 195.50),
  new Stock("MSFT", "Microsoft Corp.", 415.20),
  new Stock("GOOGL", "Alphabet Inc.", 168.75),
  new Stock("AMZN", "Amazon.com Inc.", 182.30),
  new Stock("TSLA", "Tesla Inc.", 248.90),
];

// Simulate a small random price movement for every stock on page load
stocks.forEach(function (stock) {
  stock.simulatePriceChange();
});

// Load any previously saved cash/holdings/transactions from Local Storage,
// falling back to sensible defaults for a first-time visitor.
const savedCash = localStorage.getItem(STORAGE_KEY_CASH);
const savedHoldings = localStorage.getItem(STORAGE_KEY_HOLDINGS);
const savedTransactions = localStorage.getItem(STORAGE_KEY_TRANSACTIONS);

const initialCash = savedCash !== null ? Number(savedCash) : STARTING_CASH;
const initialHoldings = savedHoldings !== null ? JSON.parse(savedHoldings) : {};
const initialTransactions = savedTransactions !== null ? JSON.parse(savedTransactions) : [];

// Create the single User instance that drives the whole app
const user = new User(initialCash, initialHoldings, initialTransactions);

// -------------------------------------------------------
// Save current state (cash, holdings, transactions) to Local Storage
// -------------------------------------------------------
function saveState() {
  localStorage.setItem(STORAGE_KEY_CASH, String(user.cash));
  localStorage.setItem(STORAGE_KEY_HOLDINGS, JSON.stringify(user.portfolio.holdings));
  localStorage.setItem(STORAGE_KEY_TRANSACTIONS, JSON.stringify(user.transactions));
}

// -------------------------------------------------------
// Helper: find a Stock object by its symbol
// -------------------------------------------------------
function findStock(symbol) {
  return stocks.find(function (s) { return s.symbol === symbol; });
}

// -------------------------------------------------------
// Helper: format a number as currency
// -------------------------------------------------------
function formatCurrency(amount) {
  return "$" + amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// =======================================================
// DOM REFERENCES
// =======================================================
const stockTableBody = document.getElementById("stock-table-body");
const portfolioTableBody = document.getElementById("portfolio-table-body");
const portfolioEmpty = document.getElementById("portfolio-empty");
const historyTableBody = document.getElementById("history-table-body");
const historyEmpty = document.getElementById("history-empty");

const tradeSymbolSelect = document.getElementById("trade-symbol");
const tradeQuantityInput = document.getElementById("trade-quantity");
const tradeCurrentPrice = document.getElementById("trade-current-price");
const tradeOwned = document.getElementById("trade-owned");
const quantityError = document.getElementById("quantity-error");
const tradeError = document.getElementById("trade-error");

const buyBtn = document.getElementById("buy-btn");
const sellBtn = document.getElementById("sell-btn");
const resetBtn = document.getElementById("reset-btn");

const summaryCash = document.getElementById("summary-cash");
const summaryInvestment = document.getElementById("summary-investment");
const summaryValue = document.getElementById("summary-value");
const summaryPL = document.getElementById("summary-pl");
const summaryCount = document.getElementById("summary-count");

// =======================================================
// RENDER FUNCTIONS
// =======================================================

// Render the market dashboard (list of all available stocks)
function renderStockTable() {
  stockTableBody.innerHTML = "";

  stocks.forEach(function (stock) {
    const change = stock.getChangePercent();
    const changeClass = change >= 0 ? "positive" : "negative";
    const changeSign = change >= 0 ? "+" : "";

    const row = document.createElement("tr");
    row.innerHTML =
      "<td class='symbol-cell'>" + stock.symbol + "</td>" +
      "<td>" + stock.name + "</td>" +
      "<td>" + formatCurrency(stock.price) + "</td>" +
      "<td class='" + changeClass + "'>" + changeSign + change.toFixed(2) + "%</td>";

    stockTableBody.appendChild(row);
  });
}

// Populate the "Stock" dropdown in the trade form
function renderStockOptions() {
  tradeSymbolSelect.innerHTML = "";

  stocks.forEach(function (stock) {
    const option = document.createElement("option");
    option.value = stock.symbol;
    option.textContent = stock.symbol + " - " + stock.name;
    tradeSymbolSelect.appendChild(option);
  });

  updateTradeInfo();
}

// Update the "Current Price" / "Shares Owned" info box in the trade form
function updateTradeInfo() {
  const symbol = tradeSymbolSelect.value;
  const stock = findStock(symbol);
  if (!stock) return;

  tradeCurrentPrice.textContent = formatCurrency(stock.price);
  tradeOwned.textContent = user.portfolio.getSharesOwned(symbol);
}

// Render the portfolio table (what the user currently owns)
function renderPortfolioTable() {
  portfolioTableBody.innerHTML = "";

  const symbols = Object.keys(user.portfolio.holdings);

  portfolioEmpty.style.display = symbols.length === 0 ? "block" : "none";

  symbols.forEach(function (symbol) {
    const holding = user.portfolio.holdings[symbol];
    const stock = findStock(symbol);
    if (!stock) return;

    const investment = holding.shares * holding.avgPrice;
    const currentValue = holding.shares * stock.price;
    const profitLoss = currentValue - investment;
    const plClass = profitLoss >= 0 ? "positive" : "negative";
    const plSign = profitLoss >= 0 ? "+" : "";

    const row = document.createElement("tr");
    row.innerHTML =
      "<td class='symbol-cell'>" + symbol + "</td>" +
      "<td>" + stock.name + "</td>" +
      "<td>" + holding.shares + "</td>" +
      "<td>" + formatCurrency(holding.avgPrice) + "</td>" +
      "<td>" + formatCurrency(stock.price) + "</td>" +
      "<td>" + formatCurrency(investment) + "</td>" +
      "<td>" + formatCurrency(currentValue) + "</td>" +
      "<td class='" + plClass + "'>" + plSign + formatCurrency(Math.abs(profitLoss)) + "</td>";

    portfolioTableBody.appendChild(row);
  });
}

// Render the transaction history table
function renderHistoryTable() {
  historyTableBody.innerHTML = "";

  historyEmpty.style.display = user.transactions.length === 0 ? "block" : "none";

  user.transactions.forEach(function (t) {
    const typeClass = t.type === "BUY" ? "type-buy" : "type-sell";

    const row = document.createElement("tr");
    row.innerHTML =
      "<td>" + t.date + "</td>" +
      "<td class='symbol-cell'>" + t.symbol + "</td>" +
      "<td class='" + typeClass + "'>" + t.type + "</td>" +
      "<td>" + t.quantity + "</td>" +
      "<td>" + formatCurrency(t.price) + "</td>" +
      "<td>" + formatCurrency(t.total) + "</td>";

    historyTableBody.appendChild(row);
  });
}

// Render the summary cards (cash, investment, value, P/L, stock count)
function renderSummary() {
  let totalInvestment = 0;
  let totalCurrentValue = 0;

  Object.keys(user.portfolio.holdings).forEach(function (symbol) {
    const holding = user.portfolio.holdings[symbol];
    const stock = findStock(symbol);
    if (!stock) return;

    totalInvestment += holding.shares * holding.avgPrice;
    totalCurrentValue += holding.shares * stock.price;
  });

  const totalProfitLoss = totalCurrentValue - totalInvestment;

  summaryCash.textContent = formatCurrency(user.cash);
  summaryInvestment.textContent = formatCurrency(totalInvestment);
  summaryValue.textContent = formatCurrency(totalCurrentValue);

  const plSign = totalProfitLoss >= 0 ? "+" : "-";
  summaryPL.textContent = plSign + formatCurrency(Math.abs(totalProfitLoss));
  summaryPL.classList.remove("positive", "negative");
  summaryPL.classList.add(totalProfitLoss >= 0 ? "positive" : "negative");

  summaryCount.textContent = user.portfolio.getStockCount();
}

// Re-render every dynamic part of the page in one call
function renderAll() {
  renderStockTable();
  renderPortfolioTable();
  renderHistoryTable();
  renderSummary();
  updateTradeInfo();
}

// =======================================================
// EVENT HANDLERS
// =======================================================

// Update trade info whenever the selected stock changes
tradeSymbolSelect.addEventListener("change", updateTradeInfo);

// Clear errors as the user edits the quantity field
tradeQuantityInput.addEventListener("input", function () {
  quantityError.textContent = "";
  tradeError.textContent = "";
  tradeQuantityInput.classList.remove("invalid");
});

// Validate the quantity field. Returns the quantity as a number, or null if invalid.
function getValidQuantity() {
  const raw = tradeQuantityInput.value.trim();
  quantityError.textContent = "";
  tradeQuantityInput.classList.remove("invalid");

  if (raw === "") {
    quantityError.textContent = "Quantity is required.";
    tradeQuantityInput.classList.add("invalid");
    return null;
  }

  const quantity = Number(raw);

  if (isNaN(quantity) || quantity <= 0 || !Number.isInteger(quantity)) {
    quantityError.textContent = "Quantity must be a whole number greater than 0.";
    tradeQuantityInput.classList.add("invalid");
    return null;
  }

  return quantity;
}

// BUY button
buyBtn.addEventListener("click", function () {
  tradeError.textContent = "";
  const quantity = getValidQuantity();
  if (quantity === null) return;

  const symbol = tradeSymbolSelect.value;
  const stock = findStock(symbol);

  const result = user.buyStock(stock, quantity);

  if (!result.success) {
    tradeError.textContent = result.message;
    return;
  }

  saveState();
  renderAll();
  tradeQuantityInput.value = "";
});

// SELL button
sellBtn.addEventListener("click", function () {
  tradeError.textContent = "";
  const quantity = getValidQuantity();
  if (quantity === null) return;

  const symbol = tradeSymbolSelect.value;
  const stock = findStock(symbol);

  const result = user.sellStock(stock, quantity);

  if (!result.success) {
    tradeError.textContent = result.message;
    return;
  }

  saveState();
  renderAll();
  tradeQuantityInput.value = "";
});

// RESET button: clears all saved data and starts fresh
resetBtn.addEventListener("click", function () {
  const confirmed = confirm("This will erase your cash balance, portfolio, and transaction history. Continue?");
  if (!confirmed) return;

  localStorage.removeItem(STORAGE_KEY_CASH);
  localStorage.removeItem(STORAGE_KEY_HOLDINGS);
  localStorage.removeItem(STORAGE_KEY_TRANSACTIONS);

  // Reload the page so the User instance is rebuilt from scratch
  location.reload();
});

// =======================================================
// INITIAL RENDER
// =======================================================
renderStockOptions();
renderAll();